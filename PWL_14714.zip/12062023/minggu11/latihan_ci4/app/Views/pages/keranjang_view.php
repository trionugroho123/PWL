<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Selamat datang di halaman keranjang</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<hody>
    <h2 align='center'>Ini adalah halaman keranjang</h2>